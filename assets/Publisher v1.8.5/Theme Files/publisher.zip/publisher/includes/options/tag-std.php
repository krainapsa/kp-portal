<?php

/**
 * => Style
 */
$fields['page_layout']          = array(
	'std' => 'default',
);
$fields['page_listing']         = array(
	'std' => 'default',
);
$fields['page_listing_excerpt'] = array(
	'std' => 'default',
);
$fields['term_posts_count']     = array(
	'std' => '',
);
$fields['term_pagination_type'] = array(
	'std' => 'default',
);


/**
 * => Title
 */
$fields['term_custom_pre_title'] = array(
	'std' => '',
);
$fields['term_custom_title']     = array(
	'std' => '',
);
$fields['hide_term_title']       = array(
	'std' => '0',
);
$fields['hide_term_description'] = array(
	'std' => '0',
);


/**
 * => Custom CSS
 */
$fields['_custom_css_code']                  = array(
	'std' => '',
);
$fields['_custom_css_class']                 = array(
	'std' => '',
);
$fields['_custom_css_desktop_code']          = array(
	'std' => '',
);
$fields['_custom_css_tablet_landscape_code'] = array(
	'std' => '',
);
$fields['_custom_css_tablet_portrait_code']  = array(
	'std' => '',
);
$fields['_custom_css_phones_code']           = array(
	'std' => '',
);
